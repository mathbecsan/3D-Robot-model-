# Assistive Companion Robot (concept model)

An original tabletop social/assistive robot concept: pear-shaped body, domed head with a recessed screen face, two small arms, a speaker grille, and a raised "call for help" button. It's about 20 cm wide and 28.5 cm tall (200 x 126 x 285 mm including the arms).

![Preview](docs/robot_preview.png)

## Files

| Path | What it is |
| --- | --- |
| `cad/out/assistive_robot.glb` | Colored model for viewing (Blender, macOS Quick Look, any glTF viewer) |
| `cad/out/robot_<material>.stl` | One STL per material group: `shell`, `joint`, `dark`, `screen`, `glow`, `alert` |
| `cad/out/robot_assembled.stl` | Everything merged, single-color preview mesh |
| `cad/build_robot.py` | Parametric generator (edit the numbers at the top, re-run) |
| `cad/render_preview.py` | Makes `docs/robot_preview.png` |

Front of the robot faces +Y, up is +Z, units are millimetres.

```bash
pip install trimesh manifold3d numpy matplotlib
python3 cad/build_robot.py
python3 cad/render_preview.py
```

## Honest limits

- This is a **solid concept model**, not a production design. The parts are watertight and fine for viewing, resin or FDM display prints, and as a base to import into Fusion/Onshape/Blender, but there is no internal cavity, no electronics bay, no fasteners, and the arms are fixed.
- Printing as a display piece: print the groups separately (or the assembled STL in one color), scale to taste, and expect supports under the arms and chin.
- The geometry is meshes, not parametric CAD features. Use `build_robot.py` to change proportions rather than editing the STLs.

## Ideas for next iterations

- Hollow shell split at the waist and neck, with a battery/PCB bay in the body
- Servo pockets in the shoulders so the arms can wave
- A real screen cutout (for example a 2.4" or 3.5" TFT) sized to the face pocket
- A weighted, self-righting base
