"""Assistive companion robot, concept model generator.

An original tabletop social/assistive robot: pear-shaped body, domed head with a
recessed screen face, two small arms, speaker grille and a raised "call for help"
button. Front of the robot faces +Y, up is +Z. Units are millimetres.

    pip install trimesh manifold3d numpy
    python3 cad/build_robot.py

Outputs (cad/out/):
  one STL per material group, an assembled STL, and a colored GLB.
"""
from pathlib import Path

import numpy as np
import trimesh
from trimesh.transformations import rotation_matrix

OUT = Path(__file__).parent / "out"

# --------------------------------------------------------------- parameters
BASE_D, BASE_H = 124.0, 14.0
BODY_C = (0, 0, 95.0)
BODY_R = (62.0, 55.0, 85.0)          # ellipsoid radii x, y, z
NECK_D, NECK_Z0, NECK_H = 40.0, 172.0, 18.0
HEAD_C = (0, 0, 235.0)
HEAD_R = (58.0, 50.0, 50.0)
SCREEN_X, SCREEN_Z0, SCREEN_Z1 = 40.0, 211.0, 262.0   # half-width, bottom, top
ARM_LEN, ARM_R, ARM_ANGLE = 78.0, 10.5, 25.0           # degrees outward from vertical
SHOULDER = (54.0, 0.0, 135.0)

COLORS = {
    "shell": (240, 240, 244, 255),   # white shell
    "joint": (60, 170, 190, 255),    # teal joints, ears, hands
    "dark": (55, 58, 66, 255),       # neck, base, camera
    "screen": (22, 26, 40, 255),     # face screen
    "glow": (140, 230, 250, 255),    # eyes + mouth
    "alert": (235, 95, 80, 255),     # help button
}


# ------------------------------------------------------------------ helpers
def ellipsoid(center, radii, sub=4):
    m = trimesh.creation.icosphere(subdivisions=sub, radius=1.0)
    m.apply_scale(radii)
    m.apply_translation(center)
    return m


def cyl_z(d, h, cx=0.0, cy=0.0, z0=0.0, sections=64):
    m = trimesh.creation.cylinder(radius=d / 2, height=h, sections=sections)
    m.apply_translation((cx, cy, z0 + h / 2))
    return m


def cyl_y(d, y0, y1, cx=0.0, cz=0.0, sections=48):
    """Cylinder along Y from y0 to y1."""
    m = trimesh.creation.cylinder(radius=d / 2, height=y1 - y0, sections=sections)
    m.apply_transform(rotation_matrix(-np.pi / 2, (1, 0, 0)))  # z axis -> +y
    m.apply_translation((cx, (y0 + y1) / 2, cz))
    return m


def box(sx, sy, sz, cx, cy, cz):
    m = trimesh.creation.box(extents=(sx, sy, sz))
    m.apply_translation((cx, cy, cz))
    return m


def capsule_between(p0, p1, radius):
    p0, p1 = np.asarray(p0, float), np.asarray(p1, float)
    v = p1 - p0
    length = np.linalg.norm(v)
    m = trimesh.creation.capsule(height=length, radius=radius, count=(24, 24))
    m.apply_transform(trimesh.geometry.align_vectors([0, 0, 1], v / length))
    m.apply_translation((p0 + p1) / 2)
    return m


def union(*ms):
    return trimesh.boolean.union(list(ms), engine="manifold")


def diff(a, *ms):
    return trimesh.boolean.difference([a, *ms], engine="manifold")


def inter(*ms):
    return trimesh.boolean.intersection(list(ms), engine="manifold")


def surf_y(radii, center, x, z):
    """y of an ellipsoid's front surface at (x, z)."""
    t = 1 - ((x - center[0]) / radii[0]) ** 2 - ((z - center[2]) / radii[2]) ** 2
    return center[1] + radii[1] * np.sqrt(max(t, 0.0))


# -------------------------------------------------------------------- parts
def build():
    parts = {}

    # --- head shell with a screen-shaped pocket, plus the screen that fills it
    head = ellipsoid(HEAD_C, HEAD_R)
    pocket = box(2 * SCREEN_X, 80, SCREEN_Z1 - SCREEN_Z0, 0, 45, (SCREEN_Z0 + SCREEN_Z1) / 2)
    head_shell = diff(head, pocket)
    screen = inter(ellipsoid(HEAD_C, np.array(HEAD_R) + 1.2), pocket)

    # --- body with speaker grille (blind holes)
    body = ellipsoid(BODY_C, BODY_R)
    grille_c = (0.0, 66.0)  # x, z
    pts = [(0.0, 0.0)]
    for ring, n in ((8.0, 6), (16.0, 12)):
        for k in range(n):
            a = 2 * np.pi * k / n
            pts.append((ring * np.cos(a), ring * np.sin(a)))
    holes = [cyl_y(3.2, 40, 75, cx=grille_c[0] + dx, cz=grille_c[1] + dz) for dx, dz in pts]
    body = diff(body, *holes)

    # --- arms: capsule from shoulder, angled outward and slightly forward
    arms, joints, hands = [], [], []
    a = np.radians(ARM_ANGLE)
    for s in (-1, 1):
        sh = np.array([s * SHOULDER[0], SHOULDER[1], SHOULDER[2]])
        end = sh + np.array([s * ARM_LEN * np.sin(a), 14.0, -ARM_LEN * np.cos(a)])
        arms.append(capsule_between(sh, end, ARM_R))
        joints.append(ellipsoid(sh, (15, 15, 15), sub=3))
        hands.append(ellipsoid(end + np.array([0, 2, -6]), (13, 11, 15), sub=3))

    parts["shell"] = union(body, head_shell, *arms)
    parts["dark"] = union(
        cyl_z(BASE_D, BASE_H),
        cyl_z(NECK_D, NECK_H, z0=NECK_Z0),
        ellipsoid((0, surf_y(HEAD_R, HEAD_C, 0, 270) - 1.0, 270), (4.0, 4.0, 4.0), sub=3),  # camera
    )
    parts["joint"] = union(
        cyl_z(BASE_D + 2, 5, z0=BASE_H - 1),                   # teal base ring
        *joints, *hands,
        ellipsoid((-HEAD_R[0] + 2, 0, HEAD_C[2]), (11, 13, 13), sub=3),   # ear pods
        ellipsoid((HEAD_R[0] - 2, 0, HEAD_C[2]), (11, 13, 13), sub=3),
    )
    parts["screen"] = screen

    eyes = []
    for s in (-1, 1):
        ey = surf_y(np.array(HEAD_R) + 1.2, HEAD_C, s * 18, 242)
        eyes.append(ellipsoid((s * 18, ey - 0.5, 242), (7.5, 3.0, 10.0), sub=3))
    my = surf_y(np.array(HEAD_R) + 1.2, HEAD_C, 0, 222)
    eyes.append(ellipsoid((0, my - 0.5, 222), (10, 3.0, 2.6), sub=3))
    parts["glow"] = union(*eyes)

    by = surf_y(BODY_R, BODY_C, 0, 122)
    parts["alert"] = cyl_y(20, by - 5, by + 4, cz=122)
    return parts


def main():
    OUT.mkdir(exist_ok=True)
    parts = build()
    scene = trimesh.Scene()
    allm = []
    for name, m in parts.items():
        m.export(OUT / f"robot_{name}.stl")
        m.visual.face_colors = COLORS[name]
        scene.add_geometry(m, node_name=name, geom_name=name)
        allm.append(m)
        print(f"{name:7s} watertight={m.is_watertight} volume={m.volume:9.0f} mm^3 faces={len(m.faces)}")
    trimesh.util.concatenate(allm).export(OUT / "robot_assembled.stl")
    scene.export(OUT / "assistive_robot.glb")
    lo = np.min([m.bounds[0] for m in allm], axis=0)
    hi = np.max([m.bounds[1] for m in allm], axis=0)
    print("overall size (mm):", np.round(hi - lo, 1).tolist())


if __name__ == "__main__":
    main()
