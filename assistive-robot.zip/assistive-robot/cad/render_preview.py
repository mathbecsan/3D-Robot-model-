"""Z-buffer preview renderer for the robot parts. Writes docs/robot_preview.png.

    python3 cad/render_preview.py
"""
from pathlib import Path

import matplotlib
import numpy as np
import trimesh

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
OUT_DIR = ROOT / "cad" / "out"
PNG = ROOT / "docs" / "robot_preview.png"

COLORS = {
    "shell": (0.94, 0.94, 0.96), "joint": (0.24, 0.67, 0.75), "dark": (0.22, 0.23, 0.26),
    "screen": (0.09, 0.10, 0.16), "glow": (0.55, 0.90, 0.98), "alert": (0.92, 0.37, 0.31),
}
ORDER = ["shell", "dark", "joint", "screen", "glow", "alert"]


def view_matrix(elev, azim):
    a, e = np.radians(azim), np.radians(elev)
    rz = np.array([[np.cos(a), -np.sin(a), 0], [np.sin(a), np.cos(a), 0], [0, 0, 1]])
    rx = np.array([[1, 0, 0], [0, np.sin(e), np.cos(e)], [0, -np.cos(e), np.sin(e)]])
    return rx @ rz  # world -> view; view z points toward the camera


def render(parts, elev, azim, size=640, span=330.0, center=(0, 0, 142)):
    R = view_matrix(elev, azim)
    img = np.ones((size, size, 3))
    zbuf = np.full((size, size), -np.inf)
    light_view = np.array([-0.4, 0.5, 0.75])  # fixed relative to the camera so every view is lit
    light_view /= np.linalg.norm(light_view)
    scale = size / span
    for name in ORDER:
        mesh, color = parts[name], np.array(COLORS[name])
        v = (mesh.vertices - np.array(center)) @ R.T
        n_view = mesh.face_normals @ R.T
        shade = n_view @ light_view
        for tri, nv, sh in zip(mesh.faces, n_view, shade):
            if nv[2] <= 0:
                continue
            p = v[tri]
            xs, ys = p[:, 0] * scale + size / 2, size / 2 - p[:, 1] * scale
            x0, x1 = int(max(np.floor(xs.min()), 0)), int(min(np.ceil(xs.max()), size - 1))
            y0, y1 = int(max(np.floor(ys.min()), 0)), int(min(np.ceil(ys.max()), size - 1))
            if x1 < x0 or y1 < y0:
                continue
            d = (ys[1] - ys[2]) * (xs[0] - xs[2]) + (xs[2] - xs[1]) * (ys[0] - ys[2])
            if abs(d) < 1e-9:
                continue
            gx, gy = np.meshgrid(np.arange(x0, x1 + 1) + 0.5, np.arange(y0, y1 + 1) + 0.5)
            w0 = ((ys[1] - ys[2]) * (gx - xs[2]) + (xs[2] - xs[1]) * (gy - ys[2])) / d
            w1 = ((ys[2] - ys[0]) * (gx - xs[2]) + (xs[0] - xs[2]) * (gy - ys[2])) / d
            w2 = 1 - w0 - w1
            inside = (w0 >= -1e-6) & (w1 >= -1e-6) & (w2 >= -1e-6)
            if not inside.any():
                continue
            z = w0 * p[0, 2] + w1 * p[1, 2] + w2 * p[2, 2]
            sub = zbuf[y0:y1 + 1, x0:x1 + 1]
            upd = inside & (z > sub + 1e-6)
            sub[upd] = z[upd]
            img[y0:y1 + 1, x0:x1 + 1][upd] = np.clip(color * (0.35 + 0.65 * max(sh, 0)), 0, 1)
    return img


def main():
    parts = {n: trimesh.load(OUT_DIR / f"robot_{n}.stl") for n in ORDER}
    # azimuth 180 looks at the robot's face (+Y); 0 looks at its back
    views = [("Front", 8, 180), ("Three-quarter", 14, 145), ("Side", 8, 90), ("Back", 8, 0)]
    fig, axes = plt.subplots(1, 4, figsize=(15, 5.2))
    for ax, (title, elev, azim) in zip(axes, views):
        ax.imshow(render(parts, elev, azim))
        ax.set_title(title, fontsize=10)
        ax.axis("off")
    fig.tight_layout()
    PNG.parent.mkdir(exist_ok=True)
    fig.savefig(PNG, dpi=120)
    print("wrote", PNG)


if __name__ == "__main__":
    main()
